-- JA Scheduler Bot DB backup
-- Generated: 2026-04-26T21:08:39.078097
-- Source: Turso libSQL
-- Restore: sqlite3 restored.db < this_file.sql
--          OR paste into Turso shell

PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;

-- Table: events
DROP TABLE IF EXISTS events;
CREATE TABLE events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        topic TEXT NOT NULL,
        start_local TEXT NOT NULL,
        duration_min INTEGER NOT NULL,
        agenda TEXT NOT NULL DEFAULT '',
        attendees TEXT NOT NULL,
        recurring TEXT,
        zoom_meeting_id TEXT NOT NULL,
        zoom_join_url TEXT NOT NULL,
        zoom_passcode TEXT NOT NULL DEFAULT '',
        calendar_event_id TEXT NOT NULL,
        calendar_event_link TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'active'
    , cancelled_occurrences TEXT DEFAULT '[]', reminders_sent TEXT DEFAULT '[]', provider TEXT NOT NULL DEFAULT 'zoom', meet_join_url TEXT NOT NULL DEFAULT '');
INSERT INTO events (id, created_at, updated_at, topic, start_local, duration_min, agenda, attendees, recurring, zoom_meeting_id, zoom_join_url, zoom_passcode, calendar_event_id, calendar_event_link, status, cancelled_occurrences, reminders_sent, provider, meet_join_url) VALUES (2, '2026-04-22T04:31:26Z', '2026-04-22T04:31:44Z', 'Tư vấn OKRs - Chị Lan', '2026-04-22T14:00:00', 60, 'Tư vấn gói Coaching OKRs', '["lan@abc.com"]', NULL, '86774194518', 'https://us06web.zoom.us/j/86774194518?pwd=xkZNuTyKccyWizt3NrXSDrz0ZhMG0p.1', '701550', 'p8oo98smu6ka5bjeoe1l9eekk0', 'https://www.google.com/calendar/event?eid=cDhvbzk4c211NmthNWJqZW9lMWw5ZWVrazAgbmd1eWVudGhpaGFpeWVuQGpvaG4udm4', 'deleted', '[]', '[]', 'zoom', '');
INSERT INTO events (id, created_at, updated_at, topic, start_local, duration_min, agenda, attendees, recurring, zoom_meeting_id, zoom_join_url, zoom_passcode, calendar_event_id, calendar_event_link, status, cancelled_occurrences, reminders_sent, provider, meet_join_url) VALUES (3, '2026-04-22T04:47:00Z', '2026-04-22T04:48:26Z', 'Tư vấn OKRs - Chị Yến', '2026-04-26T14:00:00', 120, 'Tư vấn gói Coaching OKRs', '["haiyennt1702@gmail.com"]', NULL, '82219207829', 'https://us06web.zoom.us/j/82219207829?pwd=kw7D2acZcr19h1TjXaDBbaBf9ynYRs.1', '229988', 'uu3jj1bq3lhp60g59cbejffpko', 'https://www.google.com/calendar/event?eid=dXUzamoxYnEzbGhwNjBnNTljYmVqZmZwa28gbmd1eWVudGhpaGFpeWVuQGpvaG4udm4', 'deleted', '[]', '[]', 'zoom', '');
INSERT INTO events (id, created_at, updated_at, topic, start_local, duration_min, agenda, attendees, recurring, zoom_meeting_id, zoom_join_url, zoom_passcode, calendar_event_id, calendar_event_link, status, cancelled_occurrences, reminders_sent, provider, meet_join_url) VALUES (4, '2026-04-22T04:48:45Z', '2026-04-22T04:48:56Z', 'Tư vấn OKRs - Chị Yến', '2026-04-26T14:00:00', 60, 'Tư vấn gói Coaching OKRs', '["haiyennt1702@gmail.com"]', NULL, '87838324711', 'https://us06web.zoom.us/j/87838324711?pwd=lhhyyevu487uTgtwow7qkk0e3OXSMm.1', '300144', 'fd7u3ouu5p7h0qand3pknln00s', 'https://www.google.com/calendar/event?eid=ZmQ3dTNvdXU1cDdoMHFhbmQzcGtubG4wMHMgbmd1eWVudGhpaGFpeWVuQGpvaG4udm4', 'deleted', '[]', '[]', 'zoom', '');
INSERT INTO events (id, created_at, updated_at, topic, start_local, duration_min, agenda, attendees, recurring, zoom_meeting_id, zoom_join_url, zoom_passcode, calendar_event_id, calendar_event_link, status, cancelled_occurrences, reminders_sent, provider, meet_join_url) VALUES (5, '2026-04-22T04:50:40Z', '2026-04-22T04:52:34Z', 'Yến Test', '2026-04-29T06:00:00', 120, 'Test recurring', '["haiyennt1702@gmail.com"]', '{"byday": "WE", "count": 3}', '81518062784', 'https://us06web.zoom.us/j/81518062784?pwd=ag6LDHNSSFQFIEt3fEp96aiYboay8R.1', '611546', 'hifour2s47102vk6f92ar9pt84', 'https://www.google.com/calendar/event?eid=aGlmb3VyMnM0NzEwMnZrNmY5MmFyOXB0ODRfMjAyNjA0MjhUMjMwMDAwWiBuZ3V5ZW50aGloYWl5ZW5Aam9obi52bg', 'deleted', '[]', '[]', 'zoom', '');
INSERT INTO events (id, created_at, updated_at, topic, start_local, duration_min, agenda, attendees, recurring, zoom_meeting_id, zoom_join_url, zoom_passcode, calendar_event_id, calendar_event_link, status, cancelled_occurrences, reminders_sent, provider, meet_join_url) VALUES (6, '2026-04-22T05:30:17Z', '2026-04-22T05:31:09Z', 'Test Rotate Secret', '2026-04-23T15:00:00', 30, 'Test sau khi rotate Google secret', '["haiyennt1702@gmail.com"]', NULL, '82458816124', 'https://us06web.zoom.us/j/82458816124?pwd=ha7hzaWGVAGa9oDWngIxwlRXK92Hi5.1', '458112', 'jda8r6821me5lfrucgt5h2fvs4', 'https://www.google.com/calendar/event?eid=amRhOHI2ODIxbWU1bGZydWNndDVoMmZ2czQgbmd1eWVudGhpaGFpeWVuQGpvaG4udm4', 'deleted', '[]', '[]', 'zoom', '');
INSERT INTO events (id, created_at, updated_at, topic, start_local, duration_min, agenda, attendees, recurring, zoom_meeting_id, zoom_join_url, zoom_passcode, calendar_event_id, calendar_event_link, status, cancelled_occurrences, reminders_sent, provider, meet_join_url) VALUES (7, '2026-04-22T06:41:45Z', '2026-04-22T06:42:03Z', 'Test Rotate Secret', '2026-04-23T15:00:00', 30, 'Test sau khi rotate Google secret', '["haiyennt1702@gmail.com"]', NULL, '89799865557', 'https://us06web.zoom.us/j/89799865557?pwd=mLVZCPa5UtvbRXrnMYEjlJpkSoa97F.1', '200677', 'psmfi9t53j90stt6etucc8cr70', 'https://www.google.com/calendar/event?eid=cHNtZmk5dDUzajkwc3R0NmV0dWNjOGNyNzAgbmd1eWVudGhpaGFpeWVuQGpvaG4udm4', 'deleted', '[]', '[]', 'zoom', '');
INSERT INTO events (id, created_at, updated_at, topic, start_local, duration_min, agenda, attendees, recurring, zoom_meeting_id, zoom_join_url, zoom_passcode, calendar_event_id, calendar_event_link, status, cancelled_occurrences, reminders_sent, provider, meet_join_url) VALUES (8, '2026-04-23T09:58:31Z', '2026-04-23T10:00:28Z', 'Check-in sức khoẻ', '2026-04-25T09:00:00', 120, 'Self review', '[]', NULL, '', '', '', '1404v32r8hv0ehq0fis6ac86lo', 'https://www.google.com/calendar/event?eid=MTQwNHYzMnI4aHYwZWhxMGZpczZhYzg2bG8gbmd1eWVudGhpaGFpeWVuQGpvaG4udm4', 'deleted', '[]', '[]', 'meet', 'https://meet.google.com/kuy-wddk-ttz');
INSERT INTO events (id, created_at, updated_at, topic, start_local, duration_min, agenda, attendees, recurring, zoom_meeting_id, zoom_join_url, zoom_passcode, calendar_event_id, calendar_event_link, status, cancelled_occurrences, reminders_sent, provider, meet_join_url) VALUES (9, '2026-04-24T03:37:24Z', '2026-04-24T03:37:43Z', 'Check-in sức khoẻ', '2026-04-25T09:00:00', 30, 'Tự review tuần', '[]', NULL, '', '', '', 'habin2go5d289d879tg4kt8i74', 'https://www.google.com/calendar/event?eid=aGFiaW4yZ281ZDI4OWQ4Nzl0ZzRrdDhpNzQgbmd1eWVudGhpaGFpeWVuQGpvaG4udm4', 'deleted', '[]', '[]', 'meet', 'https://meet.google.com/yik-bsqr-ocj');
INSERT INTO events (id, created_at, updated_at, topic, start_local, duration_min, agenda, attendees, recurring, zoom_meeting_id, zoom_join_url, zoom_passcode, calendar_event_id, calendar_event_link, status, cancelled_occurrences, reminders_sent, provider, meet_join_url) VALUES (10, '2026-04-25T01:15:41Z', '2026-04-25T02:47:46Z', 'Họp AI hàng tuần', '2026-04-25T08:00:00', 120, 'Họp AI', '["dangtrantuan@john.vn", "vukimthuy@john.vn", "maixuandat@okrs.vn", "ngoquynhhuong@john.vn", "nguyenmanhtoan@john.vn", "nguyenphuongthao@john.vn", "nguyenthiphuongthao@john.vn", "vungocoanh@john.vn"]', '{"byday": "SA", "count": 10}', '87075297505', 'https://us06web.zoom.us/j/87075297505?pwd=pIEewQwuGI5wv2FGjBGb0EL7fIhuFT.1', '105376', 'rngdttnsd6ne4g3g3hnu07fbag', 'https://www.google.com/calendar/event?eid=cm5nZHR0bnNkNm5lNGczZzNobnUwN2ZiYWdfMjAyNjA0MjVUMDEwMDAwWiBuZ3V5ZW50aGloYWl5ZW5Aam9obi52bg', 'active', '[]', '[]', 'zoom', '');
INSERT INTO events (id, created_at, updated_at, topic, start_local, duration_min, agenda, attendees, recurring, zoom_meeting_id, zoom_join_url, zoom_passcode, calendar_event_id, calendar_event_link, status, cancelled_occurrences, reminders_sent, provider, meet_join_url) VALUES (11, '2026-04-25T01:20:24Z', '2026-04-25T02:29:12Z', 'Check-in sức khoẻ', '2026-04-25T10:00:00', 120, 'Tự review tuần', '[]', NULL, '', '', '', 'c53jb1946qogqrlg79jkqcsm9o', 'https://www.google.com/calendar/event?eid=YzUzamIxOTQ2cW9ncXJsZzc5amtxY3NtOW8gbmd1eWVudGhpaGFpeWVuQGpvaG4udm4', 'active', '[]', '["2026-04-25T10:00:00"]', 'meet', 'https://meet.google.com/daw-xohn-fmu');
INSERT INTO events (id, created_at, updated_at, topic, start_local, duration_min, agenda, attendees, recurring, zoom_meeting_id, zoom_join_url, zoom_passcode, calendar_event_id, calendar_event_link, status, cancelled_occurrences, reminders_sent, provider, meet_join_url) VALUES (12, '2026-04-26T08:58:44Z', '2026-04-26T09:00:32Z', 'JoyLab- Thiết kế hệ thống quản trị cho kỷ nguyên AI-Native', '2025-04-29T20:00:00', 120, 'Zoom JoyLab- Thiết kế hệ thống quản trị cho kỷ nguyên AI-Native', '["ngoquynhhuong@john.vn"]', NULL, '88303180579', 'https://us06web.zoom.us/j/88303180579?pwd=0YcJF8U3bNJbfwbiOzatcyXmIeO8yI.1', '070614', 'dof4icjtbl4mg0e6gthud4dqqs', 'https://www.google.com/calendar/event?eid=ZG9mNGljanRibDRtZzBlNmd0aHVkNGRxcXMgbmd1eWVudGhpaGFpeWVuQGpvaG4udm4', 'deleted', '[]', '[]', 'zoom', '');
INSERT INTO events (id, created_at, updated_at, topic, start_local, duration_min, agenda, attendees, recurring, zoom_meeting_id, zoom_join_url, zoom_passcode, calendar_event_id, calendar_event_link, status, cancelled_occurrences, reminders_sent, provider, meet_join_url) VALUES (13, '2026-04-26T09:00:59Z', '2026-04-26T09:00:59Z', 'JoyLab- Thiết kế hệ thống quản trị cho kỷ nguyên AI-Native', '2026-04-29T20:00:00', 120, 'Zoom JoyLab- Thiết kế hệ thống quản trị cho kỷ nguyên AI-Native', '["ngoquynhhuong@john.vn"]', NULL, '82332814651', 'https://us06web.zoom.us/j/82332814651?pwd=Ao5eeCdihbYUj3A9CkrWp4VBaVvAfp.1', '986252', 'ijrb84d3b96lkfa4hica4tjhr0', 'https://www.google.com/calendar/event?eid=aWpyYjg0ZDNiOTZsa2ZhNGhpY2E0dGpocjAgbmd1eWVudGhpaGFpeWVuQGpvaG4udm4', 'active', '[]', '[]', 'zoom', '');

-- Table: bot_meta
DROP TABLE IF EXISTS bot_meta;
CREATE TABLE bot_meta (key TEXT PRIMARY KEY, value TEXT);
INSERT INTO bot_meta (key, value) VALUES ('last_digest_date', '2026-04-26');

-- Table: external_reminders_sent
DROP TABLE IF EXISTS external_reminders_sent;
CREATE TABLE external_reminders_sent (
            calendar_event_id TEXT NOT NULL,
            occurrence_iso TEXT NOT NULL,
            sent_at TEXT NOT NULL,
            PRIMARY KEY (calendar_event_id, occurrence_iso)
        );
INSERT INTO external_reminders_sent (calendar_event_id, occurrence_iso, sent_at) VALUES ('4tje63uqeu4kq7ts00tsk2n7c8_20260423T020000Z', '2026-04-23T09:00:00', '2026-04-23T08:29:00Z');
INSERT INTO external_reminders_sent (calendar_event_id, occurrence_iso, sent_at) VALUES ('23sal2hcsr2v5f88ltjsms03sp', '2026-04-25T09:00:00', '2026-04-25T01:28:12Z');

COMMIT;
